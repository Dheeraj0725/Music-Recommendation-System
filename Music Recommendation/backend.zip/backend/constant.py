class SECRETKEYS:
    JWT = 'jwt'
    ALGORITHM = 'algorithm'